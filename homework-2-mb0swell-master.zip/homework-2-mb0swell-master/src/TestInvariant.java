import edu.uwm.cs351.BallSeq;


public class TestInvariant extends BallSeq.TestInvariant {
	// content is inherited
}
